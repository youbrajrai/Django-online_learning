from django.apps import AppConfig


class OnlineClassConfig(AppConfig):
    name = 'online_class'
